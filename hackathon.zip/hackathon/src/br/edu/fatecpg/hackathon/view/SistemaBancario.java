package br.edu.fatecpg.hackathon.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import br.edu.fatecpg.hackathon.model.ContaCorrente;
import br.edu.fatecpg.hackathon.model.ContaPoupanca;
public class SistemaBancario extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtValor;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                SistemaBancario frame = new  SistemaBancario();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    public  SistemaBancario() {
        ContaCorrente contaC = new ContaCorrente(12345, "Milene Silva", 1200, 3000, 4000);
        ContaPoupanca contaP = new ContaPoupanca(12346, "Milene Silva", 1600, 3000);
        
        setTitle("Sistema Bancario");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Painel de entrada e exibição
        JPanel mainPanel = new JPanel();
        contentPane.add(mainPanel, BorderLayout.CENTER);
                        mainPanel.setLayout(null);
                
                        
                        // Botão para adicionar funcionário
                   
        
                        txtValor = new JTextField();
                        txtValor.setBounds(187, 137, 149, 23);
                        mainPanel.add(txtValor);
                        txtValor.setColumns(10);

                        JLabel lblValor = new JLabel("Valor: ");
                        lblValor.setBounds(34, 141, 70, 15);
                        mainPanel.add(lblValor);
                        
                        JRadioButton rdbtnContaCorrente = new JRadioButton("Conta Corrente");
                        rdbtnContaCorrente.setBounds(69, 85, 149, 23);
                        mainPanel.add(rdbtnContaCorrente);
                        
                        JRadioButton rdbtnContaPoupanca = new JRadioButton("Conta Poupança");
                        rdbtnContaPoupanca.setBounds(226, 85, 149, 23);
                        mainPanel.add(rdbtnContaPoupanca);
                        
                        JRadioButton radioButton = new JRadioButton();
                        radioButton.setSelected(true);
                        boolean selecionado = radioButton.isSelected();
                        ButtonGroup grupo = new ButtonGroup();
                        grupo.add(rdbtnContaCorrente);
                        grupo.add(rdbtnContaPoupanca);
                       
                        JButton btnDeposito = new JButton("Depositar");
                        btnDeposito.setBounds(337, 213, 129, 35);
                        mainPanel.add(btnDeposito);
                        btnDeposito.setBackground(new Color(255, 204, 255));
                        btnDeposito.addActionListener(e -> {
                        	 String vl = txtValor.getText();
                             double valor = Double.parseDouble(vl);
                             if(rdbtnContaPoupanca.isSelected()) {
                         		contaP.deposito(valor);
                         }else {
                         	contaC.deposito(valor);
                         }
                           
                        });
                        JButton btnTransferir = new JButton("Transferir");
                        btnTransferir.setBackground(new Color(255, 204, 204));
                        btnTransferir.setBounds(187, 213, 127, 35);
                        mainPanel.add(btnTransferir);
                        btnTransferir.addActionListener(e -> {
                       	 String vl = txtValor.getText();
                            double valor = Double.parseDouble(vl);
                            
                           if(rdbtnContaPoupanca.isSelected()) {
                           		contaP.transferencia(contaC,valor);
                           }else {
                           	contaC.transferencia(contaP,valor);
                           }
                       });
                        
                 
                     
                        // Botão para exibir média salarial
                        JButton btnSaque = new JButton("Sacar");
                        btnSaque.setBounds(34, 213, 129, 35);
                        mainPanel.add(btnSaque);
                        btnSaque.setBackground(new Color(255, 204, 255));
                        btnSaque.addActionListener(e -> {
                        	 String vl = txtValor.getText();
                             double valor = Double.parseDouble(vl);
                             
                            if(rdbtnContaPoupanca.isSelected()) {
                            		contaP.saque(valor);
                            }else {
                            	contaC.saque(valor);
                            }
                        });
                       
                                                
                        JLabel lblTipoDaConta = new JLabel("Tipo da conta");
                        lblTipoDaConta.setBounds(34, 55, 129, 15);
                        mainPanel.add(lblTipoDaConta);
          

  
    }


}