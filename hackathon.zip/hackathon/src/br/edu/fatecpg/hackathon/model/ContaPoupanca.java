package br.edu.fatecpg.hackathon.model;

public class ContaPoupanca extends Conta{

	public ContaPoupanca(int numero, String titular, double saldo, double limite) {
		super(numero, titular, saldo, limite);
	}

	@Override
	public void saque(double valor) {
		System.out.println("Não é possivel realizar saque!");
	}

}
