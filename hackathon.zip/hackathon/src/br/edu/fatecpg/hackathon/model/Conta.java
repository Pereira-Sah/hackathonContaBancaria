package br.edu.fatecpg.hackathon.model;

public class Conta {
	private int numero;
	private String titular;
	private double saldo;
	private double limite;
	
	public double getLimite() {
		return limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public Conta(int numero, String titular, double saldo, double limite) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
		this.limite = limite;
	}
	
	public void saque(double valor) {
		if(valor <= saldo){
			saldo -= valor;
			System.out.println("Saque realizado com sucesso "+ saldo);
		}else {
			System.out.println("Saque não permitido!");
		}
	}
	
	public void deposito(double valor) {
		if(valor <= limite && valor !=0){
			saldo+=valor;
			System.out.println("Deposito realizado com sucesso " + saldo);
	}else {
		System.out.println("Deposito não permitido!");
	}
	}
	
	public void transferencia(Conta conta, double valor) {
		if(valor <= limite && valor <= saldo){
			saldo-=valor;
			conta.saldo+=valor;
			System.out.println("Transferencia realizado com sucesso " + saldo);
	}else {
		System.out.println("Transferencia não permitido!");
	}
	}
}
