package br.edu.fatecpg.hackathon.model;

public class ContaCorrente extends Conta {
	private double chequeEspecial;
	public double getChequeEspecial() {
		return chequeEspecial;
	}

	public void setChequeEspecial(double chequeEspecial) {
		this.chequeEspecial = chequeEspecial;
	}

	public ContaCorrente(int numero, String titular, double saldo, double limite, double cheque) {
		super(numero, titular, saldo, limite);
		this.chequeEspecial = cheque;
	}

	double saldo = getSaldo();
	@Override
	public void saque(double valor) {

		if(valor <= saldo || valor <= chequeEspecial){
			saldo-=valor;
			setSaldo(saldo);
			System.out.println("Saque realizado com sucesso " + saldo);
		}else {
			System.out.println("Saque não permitido!");
		}
	}


	@Override
	public void transferencia(Conta conta, double valor) {
		
		if(valor <= saldo || valor <= chequeEspecial) {
			saldo-=valor;
			double saldoC = conta.getSaldo();
			saldoC+=valor;
			conta.setSaldo(saldoC);
			System.out.println("Transferencia realizado com sucesso " +saldo);
	}else {
		System.out.println("Transferencia não permitido!");
	}
	}
	
	
	
}
